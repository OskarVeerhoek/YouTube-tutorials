package episode_27;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.util.vector.Vector3f;

import utility.Camera;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;

public class TexturedModels {

	private static Camera cam;
	private static int texture;
	private static int shaderProgram;
	private static int vboHandle;
	private static int bunnyDisplayList;
	private static int diffuseLocation;

	private static TexturedModel m;
	
	public static final String VERTEX_SHADER_LOCATION = "src/episode_27/texturelight.vert";
	public static final String FRAGMENT_SHADER_LOCATION = "src/episode_27/texturelight.frag";

	public static void main(String[] args) {
		setUpDisplay();
		setUpVBOs();
		setUpCamera();
		setUpShaders();
		setUpLighting();
		while (!Display.isCloseRequested()) {
			render();
			checkInput();
			Display.update();
			Display.sync(60);
		}
		cleanUp();
		System.exit(0);
	}

	private static void checkInput() {
		cam.processMouse(1, 80, -80);
		cam.processKeyboard(16, 0.003f, 0.003f, 0.003f);

		if (Mouse.isButtonDown(0))
			Mouse.setGrabbed(true);
		else if (Mouse.isButtonDown(1))
			Mouse.setGrabbed(false);
	}

	private static void cleanUp() {
		glDeleteTextures(texture);
		glDeleteProgram(shaderProgram);
		glDeleteLists(bunnyDisplayList, 1);
		Display.destroy();
	}

	private static void render() {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		cam.applyModelviewMatrix(true);
		glUseProgram(shaderProgram);
		glUniform1f(diffuseLocation, 1.5f);
		glBindBuffer(GL_ARRAY_BUFFER, vboHandle);
		glVertexPointer(3, GL_FLOAT, 0, 0L);
		glNormalPointer(GL_FLOAT, 0, m.faces.size() * 36 * 4);
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_NORMAL_ARRAY);
		glDrawArrays(GL_TRIANGLES, 0, m.faces.size());
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
//		glCallList(bunnyDisplayList);
		glUseProgram(0);
		glLight(GL_LIGHT0, GL_POSITION,
				asFloatBuffer(cam.getX(), cam.getY(), cam.getZ(), 1));
	}

	private static void setUpLighting() {
		glShadeModel(GL_SMOOTH);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);
		glLightModel(GL_LIGHT_MODEL_AMBIENT, asFloatBuffer(new float[] { 0.05f,
				0.05f, 0.05f, 1f }));
		glLight(GL_LIGHT0, GL_POSITION,
				asFloatBuffer(new float[] { 0, 0, 0, 1 }));
		glEnable(GL_CULL_FACE);
		glCullFace(GL_BACK);
		glEnable(GL_COLOR_MATERIAL);
		glColorMaterial(GL_FRONT, GL_DIFFUSE);
	}

	private static void setUpVBOs() {
		vboHandle = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, vboHandle);
		m = null;
		try {
			m = OBJLoader
					.loadTextureModel(new File("src/episode_27/bunny.obj"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Display.destroy();
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
			Display.destroy();
			System.exit(1);
		}
		glBufferData(GL_ARRAY_BUFFER, m.faces.size() * 72, GL_STATIC_DRAW);
		FloatBuffer vertices = reserveData(m.faces.size() * 36);
		FloatBuffer normals = reserveData(m.faces.size() * 36);
		for (Face face : m.faces) {
			vertices.put(asFloats(m.vertices.get((int) face.vertex.x - 1)));
			vertices.put(asFloats(m.vertices.get((int) face.vertex.y - 1)));
			vertices.put(asFloats(m.vertices.get((int) face.vertex.z - 1)));
			normals.put(asFloats(m.normals.get((int) face.normal.x - 1)));
			normals.put(asFloats(m.normals.get((int) face.normal.y - 1)));
			normals.put(asFloats(m.normals.get((int) face.normal.z - 1)));
		}
		vertices.flip();
		normals.flip();
		glBufferSubData(GL_ARRAY_BUFFER, 0, vertices);
		glBufferSubData(GL_ARRAY_BUFFER, m.faces.size() * 36 * 4, normals);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	private static float[] asFloats(Vector3f v) {
		return new float[] { v.x, v.y, v.z };
	}

	private static FloatBuffer reserveData(int size) {
		FloatBuffer data = BufferUtils.createFloatBuffer(size);
		return data;
	}

	private static void setUpShaders() {
		shaderProgram = glCreateProgram();
		int vertexShader = glCreateShader(GL_VERTEX_SHADER);
		int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
		StringBuilder vertexShaderSource = new StringBuilder();
		StringBuilder fragmentShaderSource = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					VERTEX_SHADER_LOCATION));
			String line;
			while ((line = reader.readLine()) != null) {
				vertexShaderSource.append(line).append('\n');
			}
			reader.close();
		} catch (IOException e) {
			System.err.println("Vertex shader wasn't loaded properly.");
			Display.destroy();
			System.exit(1);
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					FRAGMENT_SHADER_LOCATION));
			String line;
			while ((line = reader.readLine()) != null) {
				fragmentShaderSource.append(line).append('\n');
			}
			reader.close();
		} catch (IOException e) {
			System.err.println("Fragment shader wasn't loaded properly.");
			Display.destroy();
			System.exit(1);
		}
		glShaderSource(vertexShader, vertexShaderSource);
		glCompileShader(vertexShader);
		if (glGetShader(vertexShader, GL_COMPILE_STATUS) == GL_FALSE) {
			System.err
					.println("Vertex shader wasn't able to be compiled correctly.");
			System.err.println(glGetShaderInfoLog(vertexShader, 1024));
		}
		glShaderSource(fragmentShader, fragmentShaderSource);
		glCompileShader(fragmentShader);
		if (glGetShader(fragmentShader, GL_COMPILE_STATUS) == GL_FALSE) {
			System.err
					.println("Fragment shader wasn't able to be compiled correctly.");
			System.err.println(glGetShaderInfoLog(fragmentShader, 1024));
		}
		glAttachShader(shaderProgram, vertexShader);
		glAttachShader(shaderProgram, fragmentShader);
		glLinkProgram(shaderProgram);
		glValidateProgram(shaderProgram);
		glDeleteShader(vertexShader);
		glDeleteShader(fragmentShader);
		diffuseLocation = glGetUniformLocation(shaderProgram,
				"diffuseIntensityModifier");
	}

	private static void setUpCamera() {
		cam = new Camera((float) Display.getWidth()
				/ (float) Display.getHeight(), -2.19f, 1.36f, 11.45f);
		cam.setFov(60);
		cam.applyProjectionMatrix();
	}

	private static void setUpDisplay() {
		try {
			Display.setDisplayMode(new DisplayMode(640, 480));
			Display.setVSyncEnabled(true);
			Display.setTitle("Textured Model Demo");
			Display.create();
		} catch (LWJGLException e) {
			System.err.println("The display wasn't initialized correctly. :(");
			Display.destroy();
			System.exit(1);
		}
	}

	private static FloatBuffer asFloatBuffer(float... values) {
		FloatBuffer buffer = BufferUtils.createFloatBuffer(values.length);
		buffer.put(values);
		buffer.flip();
		return buffer;
	}
}
